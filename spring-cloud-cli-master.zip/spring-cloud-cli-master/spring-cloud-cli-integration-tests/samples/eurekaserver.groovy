package org.test

@EnableEurekaServer
class Example {
}

