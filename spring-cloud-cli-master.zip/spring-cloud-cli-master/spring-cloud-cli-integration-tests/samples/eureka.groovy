package org.test

@EnableDiscoveryClient
class Example {
}

