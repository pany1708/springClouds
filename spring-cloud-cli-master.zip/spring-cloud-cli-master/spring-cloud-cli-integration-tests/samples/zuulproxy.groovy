package org.test

@EnableZuulProxy
class Example {
}

