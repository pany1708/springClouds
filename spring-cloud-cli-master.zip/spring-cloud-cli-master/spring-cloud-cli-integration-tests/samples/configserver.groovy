package org.test

@EnableConfigServer
class Example {
}

