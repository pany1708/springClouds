package org.test

@EnableBinding(value=Source, transport="rabbit")
class Example {
}

