Spring Boot command line features for
[Spring Cloud](https://github.com/spring-cloud).  To install, make
sure you have
[Spring Boot CLI](https://github.com/spring-projects/spring-boot)
(1.1.x with x>=5):

    $ spring version
    Spring CLI v1.1.5.RELEASE

