'use strict';

/**
 * @ngdoc function
 * @name customersStoresUiApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the customersStoresUiApp
 */
angular.module('customersStoresUiApp')
  .controller('AboutController', function ($scope) {
    $scope.awesomeThings = [
      'Spring'
    ];
  });
